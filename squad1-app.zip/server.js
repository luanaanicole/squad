// Importa dotenv
import dotenv from "dotenv";
dotenv.config();

// Exemplo de import de módulos nativos
import express from "express";

const app = express();

// Rota simples só para testar
app.get("/", (req, res) => {
  res.send("Servidor rodando com dotenv configurado!");
});

// Porta
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});