module.exports ={
  test: (req, res) => {
    res.send('Controller funcionando!');
  }
};