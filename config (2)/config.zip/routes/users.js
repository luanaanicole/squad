const express = require('express');
const router = express.Router();

// nossa "lista de usuários" só na memória por enquanto
let users = [
  // exemplo inicial (você pode apagar se quiser)
  { id: 1, nome: 'Maria', email: 'maria@email.com' },
];

// 0) rota de teste (você já viu funcionar)
router.get('/test', (req, res) => {
  res.send('Controller funcionando!');
});

// 1) listar todos os usuários
router.get('/', (req, res) => {
  res.json(users);
});

// 2) pegar UM usuário pelo id
router.get('/:id', (req, res) => {
  const id = Number(req.params.id);
  const user = users.find(u => u.id === id);
  if (!user) return res.status(404).json({ erro: 'Usuário não encontrado' });
  res.json(user);
});

// 3) criar novo usuário
router.post('/', (req, res) => {
  const { nome, email } = req.body;
  if (!nome || !email) {
    return res.status(400).json({ erro: 'Nome e email são obrigatórios' });
  }
  // checar email duplicado
  const jaExiste = users.some(u => u.email === email);
  if (jaExiste) {
    return res.status(409).json({ erro: 'Email já cadastrado' });
  }
  const novo = {
    id: users.length ? Math.max(...users.map(u => u.id)) + 1 : 1,
    nome,
    email,
  };
  users.push(novo);
  res.status(201).json(novo);
});

// 4) atualizar usuário (trocar nome e/ou email)
router.put('/:id', (req, res) => {
  const id = Number(req.params.id);
  const { nome, email } = req.body;

  const idx = users.findIndex(u => u.id === id);
  if (idx === -1) return res.status(404).json({ erro: 'Usuário não encontrado' });

  // impedir email duplicado (se vier um novo)
  if (email && users.some(u => u.email === email && u.id !== id)) {
    return res.status(409).json({ erro: 'Email já usado por outro usuário' });
  }

  users[idx] = { ...users[idx], ...(nome && { nome }), ...(email && { email }) };
  res.json(users[idx]);
});

// 5) deletar usuário
router.delete('/:id', (req, res) => {
  const id = Number(req.params.id);
  const idx = users.findIndex(u => u.id === id);
  if (idx === -1) return res.status(404).json({ erro: 'Usuário não encontrado' });

  const removido = users.splice(idx, 1)[0];
  res.json({ mensagem: 'Usuário removido', usuario: removido });
});

module.exports = router;